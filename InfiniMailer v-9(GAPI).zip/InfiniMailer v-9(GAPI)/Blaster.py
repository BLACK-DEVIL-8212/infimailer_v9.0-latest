import os
import csv
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.utils import formatdate, make_msgid
import mimetypes
import base64
import platform
import subprocess
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from fpdf import FPDF
from pyfiglet import Figlet

import os
from pyfiglet import Figlet
import platform

def generate_random_users():
    return random.randint(5, 9)

def print_with_font(text, font, color_code):
    custom_fig = Figlet(font=font, width=120)  
    ascii_art = custom_fig.renderText(text)
    print(f"\033[{color_code}m" + ascii_art.strip() + "\033[0m")

def clear_terminal():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

clear_terminal()

font = 'standard' 

print_with_font("InfiniMailer v-9.0", font, '32;1')

active_users = generate_random_users()
print_with_font(f"Currently Active Users: {active_users}", font, '96;1')

disclaimer = "Do Illegal Shits Man"
print_with_font(disclaimer, font, '91;1')

def generate_random_alphanumeric(length):
    letters_and_digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return ''.join(random.choice(letters_and_digits) for i in range(length))

def generate_numbers(length):
    letters_and_digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    symbols = "-/"
    result = ''
    symbol_added = False
    for i in range(length):
        if not symbol_added and i != 0 and random.random() < 0.2:
            result += random.choice(symbols)
            symbol_added = True
        result += random.choice(letters_and_digits)
    return result

def create_pdf_from_html(html_template, output_pdf, placeholders, recipient_email):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    for key, value in placeholders.items():
        html_template = html_template.replace(f"${key}", value)

    html_template = html_template.replace("$email", recipient_email)

    tmp_html_file = "temp.html"
    with open(tmp_html_file, "w") as tmp_file:
        tmp_file.write(html_template)

    with open(os.devnull, 'w') as devnull:
        subprocess.run(["wkhtmltopdf", tmp_html_file, output_pdf], stdout=devnull, stderr=devnull)

    os.remove(tmp_html_file)

def remove_recipient_from_users_csv(recipient_email, users_csv_file):
    lines = []
    with open(users_csv_file, 'r') as csv_file:
        reader = csv.reader(csv_file)
        for row in reader:
            if row[0] != recipient_email:
                lines.append(row)

    with open(users_csv_file, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerows(lines)

def generate_random_barcode(length):
    barcode_digits = [random.randint(0, 9) for _ in range(length)]
    return ''.join(map(str, barcode_digits))

def fetch_random_line(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
    return random.choice(lines).strip()

def get_subject_line_from_file(file_path):
    with open(file_path, 'r') as subject_file:
        subject_line = subject_file.read().strip()
    return subject_line

def get_html_body_from_file(file_path, placeholders):
    with open(file_path, 'r') as html_file:
        html_body = html_file.read()
    
    for key, value in placeholders.items():
        html_body = html_body.replace(f"${key}", value)
    
    return html_body

def get_credentials(sender_email):
    creds = None
    credential_file = f'api_keys/{sender_email}.json'
    token_file = f'Tokens/{sender_email}.json'

    if os.path.exists(token_file):
        creds = Credentials.from_authorized_user_file(token_file)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(credential_file, ['https://www.googleapis.com/auth/gmail.send'])
            creds = flow.run_local_server(port=0)

        with open(token_file, 'w') as token:
            token.write(creds.to_json())

    return creds

def build_service(credentials):
    return build('gmail', 'v1', credentials=credentials)

def send_email_with_attachment(sender, recipient_email, attachment_template_dir, plain_text_body_template_dir, count):
    try:
        attachment_template_filename = random.choice([f for f in os.listdir(attachment_template_dir) if f.endswith('.html')])
        attachment_template_path = os.path.join(attachment_template_dir, attachment_template_filename)

        placeholders = {
            "id": generate_random_alphanumeric(14),
            "invc_number": generate_random_alphanumeric(12),
            "order_number": generate_random_alphanumeric(14),
            "abc3": generate_numbers(3),
            "abc4": generate_numbers(4),
            "abc5": generate_numbers(5),
            "abc6": generate_numbers(6),
            "abc7": generate_numbers(7),
            "abc8": generate_numbers(8),
            "abc9": generate_numbers(9),
            "abc10": generate_numbers(10),
            "abc11": generate_numbers(11),
            "abc12": generate_numbers(12),
            "abc13": generate_numbers(13),
            "abc14": generate_numbers(14),
            "abc15": generate_numbers(15),
            "abc16": generate_numbers(16),
            "abc17": generate_numbers(17),
            "abc18": generate_numbers(18),
            "abc19": generate_numbers(19),
            "abc20": generate_numbers(20),
            "product": fetch_random_line('Elements/data_product.csv'),
            "charges": fetch_random_line('Elements/data_charges.csv'),
            "quantity": fetch_random_line('Elements/data_quantity.csv'),
            "amount": fetch_random_line('Elements/data_charges.csv'),
            "date": fetch_random_line('Elements/data_date.csv'),
            "number": fetch_random_line('Elements/data_number.csv'),
            "email": recipient_email,
            "barcode2": generate_random_barcode(2),
            "barcode3": generate_random_barcode(3),
            "barcode4": generate_random_barcode(4),
            "barcode5": generate_random_barcode(5),
            "barcode6": generate_random_barcode(6),
            "barcode7": generate_random_barcode(7),
            "barcode8": generate_random_barcode(8),
            "barcode9": generate_random_barcode(9),
            "barcode10": generate_random_barcode(10),
            "barcode11": generate_random_barcode(11),
            "barcode12": generate_random_barcode(12),
            "barcode13": generate_random_barcode(13),
            "barcode14": generate_random_barcode(14)
        }

        attachment_filename = f"Invoices/{placeholders['invc_number']}.pdf"
        with open(attachment_template_path, 'r') as template_file:
            attachment_template_content = template_file.read()

        create_pdf_from_html(attachment_template_content, attachment_filename, placeholders, recipient_email)

        body_file_path = plain_text_body_template_dir
        html_body = get_html_body_from_file(body_file_path, placeholders)

        credentials = get_credentials(sender['Email'])
        service = build_service(credentials)

        msg = MIMEMultipart()
        msg['From'] = f"{sender['Name']} <{sender['Email']}>"
        msg['To'] = recipient_email

        subject_file_path = "Elements/subject.txt"
        subject_line = get_subject_line_from_file(subject_file_path)
        placeholders_subject = placeholders 
        for key, value in placeholders_subject.items():
            subject_line = subject_line.replace(f"${key}", value)

        msg['Subject'] = subject_line
        msg['Date'] = formatdate(localtime=True)
        msg['Message-Id'] = make_msgid()
        msg.attach(MIMEText(html_body, 'html', 'utf-8'))

        with open(attachment_filename, 'rb') as attachment_file:
            part = MIMEApplication(attachment_file.read(), Name=os.path.basename(attachment_filename))
            part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment_filename)}"'
            msg.attach(part)

        raw_message = base64.urlsafe_b64encode(msg.as_bytes()).decode("utf-8")
        service.users().messages().send(userId="me", body={'raw': raw_message}).execute()

        remove_recipient_from_users_csv(recipient_email, 'Elements/users.csv')

        print(f"Email sent to {recipient_email} from {sender['Email']} [{count}]")

    except Exception as e:
        print(f"Error sending email to {recipient_email}: {e}")

attachment_template_dir = 'PDF'
plain_text_body_template_dir = 'Elements/body.html'

senders_info = []
with open('Elements/senders.csv', 'r') as senders_file:
    reader = csv.DictReader(senders_file)
    for row in reader:
        senders_info.append(row)

recipient_emails = []
with open('Elements/users.csv', 'r') as users_file:
    reader = csv.reader(users_file)
    for row in reader:
        recipient_emails.append(row[0])

successful_emails_sent = 0
unsuccessful_emails = []

for count, recipient_email in enumerate(recipient_emails, start=1):
    try:
        sender = random.choice(senders_info)
        send_email_with_attachment(sender, recipient_email, attachment_template_dir, plain_text_body_template_dir, count)
        successful_emails_sent += 1
    except Exception:
        unsuccessful_emails.append(recipient_email)

print(f"Total emails sent successfully: {successful_emails_sent}")
print(f"Total emails not sent: {len(unsuccessful_emails)}")